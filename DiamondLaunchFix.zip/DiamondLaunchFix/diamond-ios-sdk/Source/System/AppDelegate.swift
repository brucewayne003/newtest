//
//  AppDelegate.swift
//  diamond-ios
//
//  Created by Andrew HunzekerHesed on 4/29/23.
//

import Combine
import Osiris
import UIKit

@main
@available(iOS 15.0, *)
class AppDelegate: UIResponder, UIApplicationDelegate {

    var coordinator: AppCoordinator?
    var cancellables: Set<AnyCancellable> = []
    @Provider var requestManager: RequestManagerProtocol = RequestManager()
    let userState: UserState = .shared
    let environmentManager: EnvironmentManager = .shared

    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        _ = CustomFonts.loadFonts

        setupServices()
        setupSessionSubscriptions()

        return true
    }

    // Diamond uses a single scene. Keep the coordinator here for the existing
    // session routing and loading helpers, but let SceneDelegate own the window.
    func start(in window: UIWindow) {
        let navigationController = UINavigationController()
        coordinator = AppCoordinator(navigationController: navigationController)

        window.rootViewController = navigationController
        window.makeKeyAndVisible()
        coordinator?.start()
    }
    
    // MARK: Private Helpers
    
    private func setupSessionSubscriptions() {
        userState.$session
            .dropFirst()
            .receive(on: DispatchQueue.main)
            .sink { [weak self] session in
            switch session {
            case .loggedOut, .expired:
                self?.coordinator?.showLogin()
            case .loggedIn:
                self?.coordinator?.showHomeTab()
            }
        }
        .store(in: &cancellables)
    }
    
    private func setupServices() {
        let settingsService = UserDefaultBarcodeSettingsService(defaults: .standard)
        BarcodeSettingsService.start(withService: settingsService)
    }
    
}

@available(iOS 15.0, *)
class SceneDelegate: UIResponder, UIWindowSceneDelegate {
    var window: UIWindow?

    func scene(_ scene: UIScene,
               willConnectTo session: UISceneSession,
               options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = scene as? UIWindowScene,
              let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }

        let window = UIWindow(windowScene: windowScene)
        self.window = window
        appDelegate.start(in: window)
    }
}
