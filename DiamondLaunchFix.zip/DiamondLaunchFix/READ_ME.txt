Diamond launch fix: UIScene lifecycle

Apply this AFTER the focus configuration transfer you already used.
This package changes only these two existing Diamond files:
    Source/System/AppDelegate.swift
    Source/System/Info.plist

SceneDelegate is declared inside AppDelegate.swift. There is no separate new Swift
file to add in Xcode. Osiris, the Podfile, Pods, and the Xcode project are untouched.

1. Stop Diamond and close its workspace in Xcode on your main machine.
2. Copy this entire DiamondLaunchFix folder beside your existing repos:

    YourProjectFolder/
        osiris-ios/
        diamond-ios-sdk/
        DiamondLaunchFix/
            apply_changes.py
            manifest.json
            READ_ME.txt
            diamond-ios-sdk/  (only the two changed files)

   Do not replace your complete diamond-ios-sdk repo with the partial folder here.

3. In Terminal, from YourProjectFolder, run:

    python3 DiamondLaunchFix/apply_changes.py

   Optional preview: add --dry-run.
   The script checks files before writing and saves originals under
   .diamond-launch-backups/<timestamp>/ . Re-running skips already applied files.
   It performs no network or Git operations.
   If it reports CONFLICT, it changes nothing. Keep your local edits and compare
   the indicated file with the packaged copy before deciding what to replace.

4. Open diamond-ios-sdk/Diamond.xcworkspace and build/run on your iPhone.
   You do not need bundle install or pod install again for this change.

5. Confirm Diamond reaches its home/login screen. Check login/logout if applicable,
   open the single scanner, then background and return to the app. Continue the
   focus tests with autofocus on, macro off, back wide camera, and reticle on.

The fix registers one scene, creates the app window attached to that scene, and
keeps the existing app coordinator/session routing. It adds no scanner changes.

Validation: Info.plist syntax and scene configuration were checked. The changed
Swift source was typechecked against the local iOS SDK with unrelated app
components stubbed. A complete Diamond build and phone launch still need to be
verified on your main machine, which has the installed dependencies.
