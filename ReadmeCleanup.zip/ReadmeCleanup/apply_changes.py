#!/usr/bin/env python3
"""Apply the two README updates to sibling Osiris and Diamond repositories."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import tempfile


PACKAGE = Path(__file__).resolve().parent
REPOSITORIES = {
    "osiris-ios": ("Package.swift", "Sources/Osiris/Integration/Config/OsirisCameraConfig.swift"),
    "diamond-ios-sdk": ("Podfile", "Source/UI/BarcodeSingleScan/ViewModel/BarcodeSingleScanViewModel.swift"),
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def regular_path(path, root):
    """Refuse symlinks and non-file destinations rather than following them."""
    relative = path.relative_to(root)
    current = root
    for part in relative.parts:
        current = current / part
        if current.is_symlink():
            raise ValueError("Symlink encountered: {}".format(current))
        if current != path and current.exists() and not current.is_dir():
            raise ValueError("Expected a directory: {}".format(current))
    if path.exists() and not path.is_file():
        raise ValueError("Expected a regular file: {}".format(path))


def build_plan(root):
    manifest = json.loads((PACKAGE / "manifest.json").read_text(encoding="utf-8"))
    if manifest.get("format_version") != 1:
        raise ValueError("Unsupported transfer manifest version.")
    for name, markers in REPOSITORIES.items():
        repository = root / name
        if repository.is_symlink() or not repository.is_dir():
            raise ValueError("Repository folder not found (or is a symlink): {}".format(repository))
        for marker in markers:
            path = repository / marker
            regular_path(path, root)
            if not path.is_file():
                raise ValueError("Repository check failed; missing {}".format(path))

    plan = []
    seen = set()
    for entry in manifest["files"]:
        repository = entry["repository"]
        relative = PurePosixPath(entry["path"])
        if (repository not in REPOSITORIES or relative.is_absolute()
                or not relative.parts or ".." in relative.parts or ".git" in relative.parts
                or str(relative) != "README.md"):
            raise ValueError("Invalid manifest path: {}".format(entry))
        key = (repository, str(relative))
        if key in seen:
            raise ValueError("Duplicate manifest entry: {}".format(key))
        seen.add(key)
        payload = PACKAGE / repository / Path(*relative.parts)
        destination = root / repository / Path(*relative.parts)
        regular_path(payload, PACKAGE)
        regular_path(destination, root)
        if not payload.is_file():
            raise ValueError("Packaged file is missing: {}".format(payload))
        if payload.resolve() == destination.resolve():
            raise ValueError("Destination points into the transfer folder. Use its parent as --root.")
        data = payload.read_bytes()
        if digest(data) != entry["sha256"]:
            raise ValueError("Packaged file failed its checksum: {}".format(payload))
        before = destination.read_bytes() if destination.exists() else None
        before_hash = digest(before) if before is not None else None
        if before_hash == entry["sha256"]:
            action = "UNCHANGED"
        elif before_hash == entry["before_sha256"]:
            action = "ADD" if before is None else "UPDATE"
        else:
            action = "CONFLICT"
        mode = stat.S_IMODE((destination if before is not None else payload).stat().st_mode)
        plan.append({"entry": entry, "destination": destination, "data": data,
                     "before": before, "mode": mode, "action": action})
    if not plan:
        raise ValueError("The transfer manifest contains no files.")
    return plan


def write_atomic(path, data, mode):
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=".readme-cleanup-", dir=str(path.parent))
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(data)
        temporary.chmod(mode)
        os.replace(str(temporary), str(path))
    finally:
        if temporary.exists():
            temporary.unlink()


def apply_plan(root, changes):
    # Recheck before writing in case an editor changed a file during the preview.
    for item in changes:
        destination = item["destination"]
        regular_path(destination, root)
        current = destination.read_bytes() if destination.exists() else None
        if current != item["before"]:
            raise ValueError("File changed during preparation; rerun: {}".format(destination))

    backups_root = root / ".readme-cleanup-backups"
    if backups_root.is_symlink():
        raise ValueError("Backup directory must not be a symlink: {}".format(backups_root))
    backups_root.mkdir(exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup = Path(tempfile.mkdtemp(prefix=stamp + "-", dir=str(backups_root)))
    records = []
    # Finish all backups before changing either repository.
    for item in changes:
        entry = item["entry"]
        relative = Path(entry["repository"]) / entry["path"]
        existed = item["before"] is not None
        if existed:
            saved = backup / relative
            saved.parent.mkdir(parents=True, exist_ok=True)
            saved.write_bytes(item["before"])
            saved.chmod(item["mode"])
        records.append({"path": relative.as_posix(), "existed_before": existed})
    (backup / "backup-info.json").write_text(json.dumps({
        "destination_root": str(root), "files": records
    }, indent=2) + "\n", encoding="utf-8")
    print("\nBackup: {}".format(backup), flush=True)

    written = []
    try:
        for item in changes:
            destination = item["destination"]
            regular_path(destination, root)
            current = destination.read_bytes() if destination.exists() else None
            if current != item["before"]:
                raise ValueError("File changed during application: {}".format(destination))
            written.append(item)
            write_atomic(destination, item["data"], item["mode"])
            if digest(destination.read_bytes()) != item["entry"]["sha256"]:
                raise OSError("Verification failed: {}".format(destination))
    except (Exception, KeyboardInterrupt):
        print("Application interrupted; restoring files already written.", file=sys.stderr)
        for item in reversed(written):
            try:
                regular_path(item["destination"], root)
                current = item["destination"].read_bytes() if item["destination"].exists() else None
                if current == item["before"]:
                    continue
                if current != item["data"]:
                    print("File changed outside this script; leaving it untouched: {}. Backup: {}".format(
                        item["destination"], backup), file=sys.stderr)
                    continue
                if item["before"] is None:
                    item["destination"].unlink()
                else:
                    write_atomic(item["destination"], item["before"], item["mode"])
            except (OSError, ValueError) as error:
                print("Restore failed for {}: {}. Original backup: {}".format(
                    item["destination"], error, backup), file=sys.stderr)
        raise
    print("Applied {} files successfully.".format(len(changes)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=PACKAGE.parent,
                        help="Folder containing osiris-ios and diamond-ios-sdk (default: transfer folder's parent).")
    parser.add_argument("--dry-run", action="store_true", help="Check and list changes without writing anything.")
    parser.add_argument("--overwrite-conflicts", action="store_true",
                        help="Replace differing local files with the packaged versions, backing them up first.")
    args = parser.parse_args()
    root = args.root.expanduser().resolve()
    try:
        plan = build_plan(root)
        print("Destination: {}\n".format(root))
        for item in plan:
            entry = item["entry"]
            print("{:<10} {}/{}".format(item["action"], entry["repository"], entry["path"]))
        conflicts = [item for item in plan if item["action"] == "CONFLICT"]
        if conflicts and not args.overwrite_conflicts:
            print("\nNo files changed. CONFLICT files differ from both the original and packaged versions.\n"
                  "Review them first. To deliberately replace those files too, rerun with\n"
                  "--overwrite-conflicts. Their current contents will be backed up.", file=sys.stderr)
            return 2
        if args.dry_run:
            print("\nPreview only; no files changed.")
            return 0
        changes = [item for item in plan if item["action"] != "UNCHANGED"]
        if not changes:
            print("\nAll {} packaged files are already applied. No files changed.".format(len(plan)))
            return 0
        apply_plan(root, changes)
        print("\nDone: only the two README.md files were updated. No build or pod install is needed.")
        return 0
    except (OSError, ValueError, KeyError, TypeError) as error:
        print("ERROR: {}".format(error), file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("Cancelled.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    sys.exit(main())
