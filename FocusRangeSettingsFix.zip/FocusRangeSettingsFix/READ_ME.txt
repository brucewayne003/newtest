Autofocus range settings fix

This is an incremental update AFTER the focus configuration files you already applied.
It also works alongside the separate DiamondLaunchFix; that launch fix is preserved.

CHANGED FILES (all are existing files)

osiris-ios/
    Sources/OsirisCamera/OsirisScanner/ViewModel/OsirisScannerViewModel.swift

diamond-ios-sdk/
    Source/UI/BarcodeSingleScan/ViewModel/BarcodeSingleScanViewModel.swift
    README.md

WHAT CHANGED

The retained camera manager reloads saved settings before applying camera changes,
so its old Near value cannot overwrite a newly saved None or Far selection on return.
Diamond passes the saved selection into OsirisCameraConfig:
    None -> unrestricted
    Near -> near
    Far  -> far
Continuous focus remains targeted at the scanning rectangle's centre.
The SDK defaults are unchanged; this does not change the app's saved choice to None.

APPLY ON YOUR MAIN MACHINE

1. Stop Diamond and close its Xcode workspace.
2. Copy this WHOLE FocusRangeSettingsFix folder beside your existing repositories:

    YourProjectFolder/
        osiris-ios/
        diamond-ios-sdk/
        FocusRangeSettingsFix/
            apply_changes.py
            manifest.json
            READ_ME.txt
            osiris-ios/       (partial set of changed files)
            diamond-ios-sdk/  (partial set of changed files)

   Do not replace complete repository folders with the partial folders in this package.

3. Open Terminal in YourProjectFolder and run:

    python3 FocusRangeSettingsFix/apply_changes.py

   Optional preview:
    python3 FocusRangeSettingsFix/apply_changes.py --dry-run

   If the package is elsewhere, add --root "/path/to/YourProjectFolder".
   Originals are backed up under .focus-range-backups/<timestamp>/.
   If any file differs from both the expected old file and the new file, the script
   reports CONFLICT and changes nothing. Review it before overwriting local edits.
   Re-running skips already applied files. No Git or network operations are used.

4. Open diamond-ios-sdk/Diamond.xcworkspace, build and run on your iPhone.
   No bundle install or pod install is needed for this update with your existing
   local-pod setup; no files were added to build targets and dependencies are unchanged.

VERIFY

In single-scan settings, use the back wide camera, autofocus on, macro off, and the
reticle on. Choose None, use Back to return to the scanner, then reopen settings.
None should still be selected. Repeat with Far and Near. Close/reopen the app and
confirm the last selection remains saved. Finally choose None for unrestricted tests.

Filter the Xcode console for [ScannerFocus]. After returning to the scanner, the
configured log should show range=unrestricted, range=far, or range=near respectively.
The range is a preference and depends on camera support; it cannot overcome the
lens's physical minimum focus distance. Test the same barcode at several distances.
The centre-target test and two-second return after a tap are described in README.md.

VALIDATION

Offline iOS compiler checks passed for Osiris, OsirisBarcode, and OsirisCamera.
The actual Diamond view-model file passed a targeted typecheck against those modules.
An isolated regression harness uses the production settings-loading method, Codable
preferences/persistence, macro/smooth preference updates, and Diamond range mapping.
It reproduces the old reset, then checks saved range round-trips with camera operations
replaced by test doubles. This does not replace the full Diamond build and device test.
