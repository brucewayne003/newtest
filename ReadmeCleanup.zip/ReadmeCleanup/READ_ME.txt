README documentation cleanup

This package updates only:
    osiris-ios/README.md
    diamond-ios-sdk/README.md

The script applies complete README files and backs up the previous versions.
It leaves the Podfile, Swift files, Xcode project, and other files untouched.
Keep this helper folder outside both repositories; only the two updated READMEs
belong in the repository changes.

Place the extracted folder beside your existing repositories:

    YourProjectFolder/
        osiris-ios/
        diamond-ios-sdk/
        ReadmeCleanup/
            apply_changes.py
            manifest.json
            READ_ME.txt
            osiris-ios/README.md
            diamond-ios-sdk/README.md

In Terminal, from YourProjectFolder, run:

    python3 ReadmeCleanup/apply_changes.py

Optional preview:

    python3 ReadmeCleanup/apply_changes.py --dry-run

If the folder is somewhere else, add --root "/path/to/YourProjectFolder".
Python 3 is sufficient. No extra packages, network access, or Git commands are used.
No build or pod install is needed after this documentation-only update.

The expected previous READMEs are from FocusCenterTransfer (Osiris) and
FocusRangeSettingsFix (Diamond). Running again skips already updated files.
Original files are saved under .readme-cleanup-backups/<timestamp>/.

If the script reports CONFLICT, neither README is changed. The existing file has
additional edits or is a different version; compare it with the packaged copy
before choosing to replace it. The script supports --overwrite-conflicts only
for deliberately replacing those files too, with a backup. It does not merge edits.

The Diamond README now describes published SDK dependencies. This script does
not change dependency pins. Diamond's new focus configuration requires an SDK
release containing those APIs before replacing the local test dependencies.
